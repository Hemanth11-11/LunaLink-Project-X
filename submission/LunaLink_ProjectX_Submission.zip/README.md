# LunaLink Engineering Simulator

LunaLink is a preliminary Python mission-analysis tool for the Project X brief.
It models the fixed 500 x 36,000 km, 63.4 deg Earth orbit and all four selected
subsystems: EPS, TCS, ADCS, and TT&C.

This tool is NASA/ECSS-inspired, not flight-qualified. Flight qualification would
require formal IV&V, independent model correlation, configuration-controlled
requirements, and authority acceptance.

## Quick Start

Create the Python 3.13 environment:

```bash
python3.13 -m venv .venv
.venv/bin/pip install -r code/requirements.txt
```

Run the simulator and checks:

```bash
.venv/bin/python code/main_simulation.py --quick --out outputs/ci
.venv/bin/python report/build_report.py --evidence outputs/ci --out report/LunaLink_Report_Draft.md
MPLCONFIGDIR=.cache/matplotlib .venv/bin/python -m pytest -q
.venv/bin/ruff check code
```

Optional GUI:

```bash
.venv/bin/streamlit run code/main_gui.py
```

## Outputs

- `outputs/ci/*_timeseries.csv`: mission and subsystem time histories.
- `outputs/ci/validation_metrics.csv`: pass/warn/fail checks.
- `outputs/ci/trade_results.csv`: EPS array/battery sizing trade.
- `outputs/ci/lhs_samples.csv`: Latin Hypercube design samples.
- `outputs/ci/monte_carlo_samples.csv`: Monte Carlo design samples.
- `outputs/ci/formula_traceability.csv`: requirement/formula/reference/test traceability.
- `outputs/ci/figures/*.png`: engineering figures and one Pareto-style trade plot.
- `outputs/ci/scenario_exports/*`: GMAT/Orekit-style scenario seeds and validation recipe.
- `report/LunaLink_Report_Draft.md`: generated report from the evidence bundle.

## Baseline Mission

- Orbit: 500 x 36,000 km altitude, inclination 63.4 deg.
- Period: about 10.6845 h from the fixed altitudes.
- Simulation duration: at least 36 h.
- Spacecraft mass: 500 kg.
- EOL power budget: 1.2 kW.
- Earth downlink: X-band, at least 100 Mbps in contact.
- Moon link: UHF 400-512 MHz class low-rate link.
- Ground station: Ottobrunn, 48.07 deg N, 11.65 deg E, minimum elevation 5 deg.

## Engineering Notes

The simulator uses SI internally and intentionally favors transparent equations
over hidden black-box behavior. It includes WGS84 ground geometry, numerical
J2 propagation, explicit EPS array incidence modes, mixed-coating thermal
surfaces, full Euler ADCS rate dynamics, and expanded RF link-budget evidence.
The current dynamics are suitable for early engineering trade studies, not
operations or flight certification.
