LunaLink Engineering Simulator - Project X

Clean install:
  python3.13 -m venv .venv
  .venv/bin/pip install -r code/requirements.txt

Run headless simulation:
  MPLCONFIGDIR=.cache/matplotlib .venv/bin/python code/main_simulation.py --out outputs/baseline

Build reports:
  .venv/bin/python report/build_report.py --evidence outputs/baseline --out report/LunaLink_Baseline_Report.md
  MPLCONFIGDIR=.cache/matplotlib .venv/bin/python report/build_pdf_report.py --evidence outputs/baseline --out report/LunaLink_Final_Report.pdf

Launch GUI:
  .venv/bin/streamlit run code/main_gui.py

Run verification:
  .venv/bin/ruff check code
  MPLCONFIGDIR=.cache/matplotlib .venv/bin/python -m pytest -q

Notes:
  The tool is a preliminary NASA/ECSS-inspired engineering simulator for the
  Project X brief. It is not flight-qualified or certified. Certification use
  would require independent validation, IV&V, and authority acceptance.
