"""Streamlit GUI for the LunaLink engineering simulator."""

from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from lunalink.adcs import AdcsConfig, run_adcs
from lunalink.config import MissionConfig, SimulationConfig, default_mission_config
from lunalink.constants import EARTH_RADIUS_M, RAD2DEG
from lunalink.eps import EpsConfig, run_eps
from lunalink.simulation import run_mission
from lunalink.thermal import ThermalConfig, default_face_coatings, run_thermal
from lunalink.ttc import default_uhf_link_config, default_xband_link_config, run_ttc
from lunalink.validation import metrics_to_dataframe

PROJECT_SCOPE_ROWS = [
    {
        "area": "Mission",
        "pdf_requirement": "Fixed 500 x 36,000 km, 63.4 deg HEO for >= 36 h",
        "dashboard_evidence": "Mission metrics, 3D orbit, altitude/contact/eclipse plots",
    },
    {
        "area": "EPS",
        "pdf_requirement": "Power modes, array/battery sizing, SOC over 3+ orbits",
        "dashboard_evidence": "Live array, duty-cycle, battery, and load controls",
    },
    {
        "area": "TCS",
        "pdf_requirement": "Coatings, lumped thermal model, six faces, internal temps",
        "dashboard_evidence": "Coating and dissipation controls with temperature envelope",
    },
    {
        "area": "ADCS",
        "pdf_requirement": "Detumble, wheel momentum, torques, 3D orientation",
        "dashboard_evidence": "Quaternion-driven 3D spacecraft, rates, torques, momentum",
    },
    {
        "area": "TT&C",
        "pdf_requirement": "Earth/Moon link budgets, windows, data volume, map",
        "dashboard_evidence": "Link controls, budget table, ground track, windows",
    },
    {
        "area": "Submission",
        "pdf_requirement": "Python GUI, headless script, assumptions, references",
        "dashboard_evidence": "Evidence tab, validation table, report/report-builder links",
    },
]


def build_gui_config(output_step_s: float = 600.0) -> MissionConfig:
    base = default_mission_config()
    return MissionConfig(
        orbit=base.orbit,
        spacecraft=base.spacecraft,
        ground_station=base.ground_station,
        simulation=SimulationConfig(
            epoch_utc=base.simulation.epoch_utc,
            duration_s=36.0 * 3600.0,
            output_step_s=output_step_s,
        ),
    )


@st.cache_data(show_spinner=False)
def _run_cached(output_step_s: float) -> dict[str, pd.DataFrame | dict]:
    results = run_mission(build_gui_config(output_step_s=output_step_s))
    return {
        "config": asdict(results.config),
        "environment": results.environment,
        "eps": results.eps,
        "thermal": results.thermal,
        "adcs": results.adcs,
        "ttc": results.ttc,
        "summaries": results.summaries,
        "validation": metrics_to_dataframe(results.validation_metrics),
    }


def mission_spec_table(config: dict[str, Any]) -> pd.DataFrame:
    orbit = config["orbit"]
    spacecraft = config["spacecraft"]
    ground = config["ground_station"]
    return pd.DataFrame(
        [
            ("Orbit", "500 x 36,000 km HEO, Molniya-type inclination"),
            ("Inclination", f"{orbit['inclination_rad'] * RAD2DEG:.1f} deg"),
            ("Computed period", f"{orbit['period_s'] / 3600.0:.4f} h"),
            ("Simulation span", "36 h, at least 3 project orbits"),
            ("Spacecraft mass", f"{spacecraft['mass_kg']:.0f} kg"),
            (
                "Envelope",
                (
                    f"{spacecraft['length_x_m']:.1f} x {spacecraft['length_y_m']:.1f} "
                    f"x {spacecraft['length_z_m']:.1f} m"
                ),
            ),
            ("EOL power budget", f"{spacecraft['eol_power_budget_w'] / 1000.0:.1f} kW"),
            (
                "Ground station",
                (
                    f"{ground['name']} "
                    f"({ground['latitude_rad'] * RAD2DEG:.2f} N, "
                    f"{ground['longitude_rad'] * RAD2DEG:.2f} E)"
                ),
            ),
            ("Minimum elevation", f"{ground['min_elevation_rad'] * RAD2DEG:.1f} deg"),
        ],
        columns=["parameter", "value"],
    )


def build_spacecraft_figure(
    config: dict[str, Any],
    quaternion: tuple[float, float, float, float] = (1.0, 0.0, 0.0, 0.0),
) -> go.Figure:
    spacecraft = config["spacecraft"]
    lx = float(spacecraft["length_x_m"])
    ly = float(spacecraft["length_y_m"])
    lz = float(spacecraft["length_z_m"])

    fig = go.Figure()
    _add_box(fig, "MLI-wrapped bus", (0.0, 0.0, 0.0), (lx, ly, lz), quaternion, "#c9972e", 0.96)
    _add_box(fig, "Payload deck", (0.0, 0.0, lz / 2.0 + 0.045), (1.55, 1.05, 0.08),
             quaternion, "#f5d36b", 0.95)
    _add_box(fig, "Radiator panel", (-lx / 2.0 - 0.02, 0.0, 0.0), (0.04, 0.92, 0.62),
             quaternion, "#e7eef5", 0.95)
    _add_box(fig, "Solar array +Y", (0.0, ly / 2.0 + 1.25, 0.0), (1.9, 2.35, 0.045),
             quaternion, "#123a8c", 0.88)
    _add_box(fig, "Solar array -Y", (0.0, -ly / 2.0 - 1.25, 0.0), (1.9, 2.35, 0.045),
             quaternion, "#123a8c", 0.88)
    _add_panel_grid(fig, quaternion, y_center=ly / 2.0 + 1.25, panel_size=(1.9, 2.35))
    _add_panel_grid(fig, quaternion, y_center=-ly / 2.0 - 1.25, panel_size=(1.9, 2.35))
    _add_antenna(fig, quaternion, lx)
    _add_low_gain_antennas(fig, quaternion, lx, ly)
    _add_axes(fig, quaternion, scale=1.7)

    fig.update_layout(
        height=460,
        margin={"l": 0, "r": 0, "t": 24, "b": 0},
        template="plotly_white",
        scene={
            "aspectmode": "data",
            "xaxis": {"title": "Body X m", "showbackground": False},
            "yaxis": {"title": "Body Y m", "showbackground": False},
            "zaxis": {"title": "Body Z m", "showbackground": False},
            "camera": {"eye": {"x": 2.1, "y": 1.7, "z": 1.3}},
        },
        showlegend=True,
        legend={"orientation": "h", "y": 1.02},
    )
    return fig


def build_orbit_figure(environment: pd.DataFrame, sample_stride: int = 1) -> go.Figure:
    stride = max(1, int(sample_stride))
    sampled = environment.iloc[::stride].copy()
    x_km = sampled["x_eci_m"] / 1000.0
    y_km = sampled["y_eci_m"] / 1000.0
    z_km = sampled["z_eci_m"] / 1000.0

    fig = go.Figure()
    _add_earth_surface(fig)
    moon_center_km = _moon_center_from_environment(sampled.iloc[-1])
    _add_moon_surface(fig, moon_center_km)
    fig.add_trace(
        go.Scatter3d(
            x=x_km,
            y=y_km,
            z=z_km,
            mode="lines",
            name="HEO trajectory",
            line={"color": "#0f766e", "width": 5},
        )
    )
    contact = sampled[sampled["gs_contact_flag"]]
    if not contact.empty:
        fig.add_trace(
            go.Scatter3d(
                x=contact["x_eci_m"] / 1000.0,
                y=contact["y_eci_m"] / 1000.0,
                z=contact["z_eci_m"] / 1000.0,
                mode="markers",
                name="Ottobrunn contact",
                marker={"size": 4, "color": "#16a34a"},
            )
        )
    eclipse = sampled[sampled["eclipse_flag"]]
    if not eclipse.empty:
        fig.add_trace(
            go.Scatter3d(
                x=eclipse["x_eci_m"] / 1000.0,
                y=eclipse["y_eci_m"] / 1000.0,
                z=eclipse["z_eci_m"] / 1000.0,
                mode="markers",
                name="Eclipse samples",
                marker={"size": 3, "color": "#7c3aed"},
            )
        )
    current = sampled.iloc[-1]
    fig.add_trace(
        go.Scatter3d(
            x=[current["x_eci_m"] / 1000.0],
            y=[current["y_eci_m"] / 1000.0],
            z=[current["z_eci_m"] / 1000.0],
            mode="markers",
            name="36 h state",
            marker={"size": 7, "color": "#dc2626", "symbol": "diamond"},
        )
    )
    sc_position_km = np.array(
        [
            current["x_eci_m"] / 1000.0,
            current["y_eci_m"] / 1000.0,
            current["z_eci_m"] / 1000.0,
        ],
        dtype=float,
    )
    fig.add_trace(
        go.Scatter3d(
            x=[sc_position_km[0], moon_center_km[0]],
            y=[sc_position_km[1], moon_center_km[1]],
            z=[sc_position_km[2], moon_center_km[2]],
            mode="lines",
            name="UHF Moon relay line",
            line={"color": "#65a30d", "width": 3, "dash": "dash"},
        )
    )
    earth_intercept_km = sc_position_km / np.linalg.norm(sc_position_km) * (
        EARTH_RADIUS_M / 1000.0
    )
    fig.add_trace(
        go.Scatter3d(
            x=[sc_position_km[0], earth_intercept_km[0]],
            y=[sc_position_km[1], earth_intercept_km[1]],
            z=[sc_position_km[2], earth_intercept_km[2]],
            mode="lines",
            name="X-band Earth downlink line",
            line={"color": "#0284c7", "width": 3, "dash": "dash"},
        )
    )
    fig.update_layout(
        height=640,
        margin={"l": 0, "r": 0, "t": 20, "b": 0},
        template="plotly_white",
        scene={
            "aspectmode": "data",
            "xaxis": {"title": "ECI X km", "showbackground": False},
            "yaxis": {"title": "ECI Y km", "showbackground": False},
            "zaxis": {"title": "ECI Z km", "showbackground": False},
        },
        legend={"orientation": "h", "y": 1.02},
    )
    return fig


def build_ground_track_figure(environment: pd.DataFrame) -> go.Figure:
    lon_deg = (environment["lon_rad"] * RAD2DEG + 180.0) % 360.0 - 180.0
    lat_deg = environment["lat_rad"] * RAD2DEG
    contact = environment["gs_contact_flag"]
    fig = go.Figure()
    fig.add_trace(
        go.Scattergeo(
            lon=lon_deg,
            lat=lat_deg,
            mode="lines",
            name="Ground track",
            line={"color": "#0f766e", "width": 2},
        )
    )
    fig.add_trace(
        go.Scattergeo(
            lon=lon_deg[contact],
            lat=lat_deg[contact],
            mode="markers",
            name="Ottobrunn contact",
            marker={"size": 7, "color": "#16a34a"},
        )
    )
    fig.add_trace(
        go.Scattergeo(
            lon=[11.65],
            lat=[48.07],
            mode="markers+text",
            name="Ottobrunn GS",
            text=["Ottobrunn"],
            textposition="top center",
            marker={"size": 9, "color": "#dc2626"},
        )
    )
    fig.update_layout(
        height=410,
        margin={"l": 0, "r": 0, "t": 12, "b": 0},
        template="plotly_white",
        geo={
            "projection_type": "natural earth",
            "showland": True,
            "landcolor": "#f4f7f5",
            "showocean": True,
            "oceancolor": "#e6f0fa",
            "showcountries": True,
        },
    )
    return fig


def _install_style() -> None:
    st.markdown(
        """
        <style>
        .block-container {padding-top: 1.6rem; padding-bottom: 2rem;}
        h1, h2, h3 {letter-spacing: 0;}
        div[data-testid="stMetric"] {
            border: 1px solid #d9e2ec;
            border-radius: 8px;
            padding: 0.72rem 0.78rem;
            background: #ffffff;
        }
        div[data-testid="stMetric"] label {color: #334155;}
        .lunalink-callout {
            border-left: 4px solid #0f766e;
            background: #f8fafc;
            padding: 0.8rem 1rem;
            border-radius: 6px;
            margin-bottom: 1rem;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def _add_box(
    fig: go.Figure,
    name: str,
    center: tuple[float, float, float],
    size: tuple[float, float, float],
    quaternion: tuple[float, float, float, float],
    color: str,
    opacity: float,
) -> None:
    cx, cy, cz = center
    sx, sy, sz = (value / 2.0 for value in size)
    vertices = np.array(
        [
            [cx - sx, cy - sy, cz - sz],
            [cx + sx, cy - sy, cz - sz],
            [cx + sx, cy + sy, cz - sz],
            [cx - sx, cy + sy, cz - sz],
            [cx - sx, cy - sy, cz + sz],
            [cx + sx, cy - sy, cz + sz],
            [cx + sx, cy + sy, cz + sz],
            [cx - sx, cy + sy, cz + sz],
        ],
        dtype=float,
    )
    vertices = _rotate_points(vertices, quaternion)
    triangles = np.array(
        [
            [0, 1, 2],
            [0, 2, 3],
            [4, 6, 5],
            [4, 7, 6],
            [0, 4, 5],
            [0, 5, 1],
            [1, 5, 6],
            [1, 6, 2],
            [2, 6, 7],
            [2, 7, 3],
            [3, 7, 4],
            [3, 4, 0],
        ]
    )
    fig.add_trace(
        go.Mesh3d(
            x=vertices[:, 0],
            y=vertices[:, 1],
            z=vertices[:, 2],
            i=triangles[:, 0],
            j=triangles[:, 1],
            k=triangles[:, 2],
            name=name,
            color=color,
            opacity=opacity,
            flatshading=True,
        )
    )


def _add_antenna(fig: go.Figure, quaternion: tuple[float, float, float, float], lx: float) -> None:
    theta = np.linspace(0.0, 2.0 * np.pi, 48)
    radius = np.linspace(0.0, 0.38, 14)
    theta_grid, radius_grid = np.meshgrid(theta, radius)
    dish_local = np.column_stack(
        [
            (lx / 2.0 + 0.42 - 0.18 * (radius_grid.ravel() / 0.38) ** 2),
            (radius_grid * np.cos(theta_grid)).ravel(),
            (radius_grid * np.sin(theta_grid)).ravel(),
        ]
    )
    boom = np.array([[lx / 2.0, 0.0, 0.0], [lx / 2.0 + 0.7, 0.0, 0.0]], dtype=float)
    dish = _rotate_points(dish_local, quaternion)
    boom = _rotate_points(boom, quaternion)
    faces_i: list[int] = []
    faces_j: list[int] = []
    faces_k: list[int] = []
    n_theta = len(theta)
    for r_index in range(len(radius) - 1):
        for theta_index in range(n_theta - 1):
            a = r_index * n_theta + theta_index
            b = a + 1
            c = a + n_theta
            d = c + 1
            faces_i.extend([a, b])
            faces_j.extend([c, d])
            faces_k.extend([b, c])
    fig.add_trace(
        go.Mesh3d(
            x=dish[:, 0],
            y=dish[:, 1],
            z=dish[:, 2],
            i=faces_i,
            j=faces_j,
            k=faces_k,
            name="High-gain antenna",
            color="#d8dee8",
            opacity=0.92,
            flatshading=True,
        )
    )
    fig.add_trace(
        go.Scatter3d(
            x=boom[:, 0],
            y=boom[:, 1],
            z=boom[:, 2],
            mode="lines",
            name="Antenna boom",
            line={"color": "#111827", "width": 5},
            showlegend=False,
        )
    )


def _add_panel_grid(
    fig: go.Figure,
    quaternion: tuple[float, float, float, float],
    y_center: float,
    panel_size: tuple[float, float],
) -> None:
    width_x, width_y = panel_size
    x_lines = np.linspace(-width_x / 2.0, width_x / 2.0, 5)
    y_lines = np.linspace(y_center - width_y / 2.0, y_center + width_y / 2.0, 7)
    segments = []
    for x_value in x_lines:
        segments.append([[x_value, y_center - width_y / 2.0, 0.035],
                         [x_value, y_center + width_y / 2.0, 0.035]])
    for y_value in y_lines:
        segments.append([[-width_x / 2.0, y_value, 0.04], [width_x / 2.0, y_value, 0.04]])
    for segment in segments:
        points = _rotate_points(np.array(segment, dtype=float), quaternion)
        fig.add_trace(
            go.Scatter3d(
                x=points[:, 0],
                y=points[:, 1],
                z=points[:, 2],
                mode="lines",
                name="Solar cell grid",
                line={"color": "#60a5fa", "width": 2},
                showlegend=False,
            )
        )


def _add_low_gain_antennas(
    fig: go.Figure,
    quaternion: tuple[float, float, float, float],
    lx: float,
    ly: float,
) -> None:
    for y_sign in (-1.0, 1.0):
        points = np.array(
            [[-lx / 2.0, y_sign * ly / 2.0, 0.0], [-lx / 2.0 - 0.42, y_sign * ly / 2.0, 0.22]],
            dtype=float,
        )
        points = _rotate_points(points, quaternion)
        fig.add_trace(
            go.Scatter3d(
                x=points[:, 0],
                y=points[:, 1],
                z=points[:, 2],
                mode="lines+markers",
                name="Low-gain UHF antenna",
                line={"color": "#84cc16", "width": 4},
                marker={"size": 3, "color": "#84cc16"},
                showlegend=y_sign > 0.0,
            )
        )


def _add_axes(fig: go.Figure, quaternion: tuple[float, float, float, float], scale: float) -> None:
    axes = [
        ("+X", [scale, 0.0, 0.0], "#dc2626"),
        ("+Y", [0.0, scale, 0.0], "#16a34a"),
        ("+Z", [0.0, 0.0, scale], "#2563eb"),
    ]
    origin = np.zeros((1, 3), dtype=float)
    for label, endpoint, color in axes:
        points = np.vstack([origin, np.array(endpoint, dtype=float).reshape(1, 3)])
        points = _rotate_points(points, quaternion)
        fig.add_trace(
            go.Scatter3d(
                x=points[:, 0],
                y=points[:, 1],
                z=points[:, 2],
                mode="lines+text",
                text=["", label],
                textposition="top center",
                name=label,
                line={"color": color, "width": 6},
                showlegend=False,
            )
        )


def _rotate_points(
    points: np.ndarray, quaternion: tuple[float, float, float, float]
) -> np.ndarray:
    q = np.asarray(quaternion, dtype=float)
    norm = float(np.linalg.norm(q))
    if norm == 0.0:
        return points.copy()
    q = q / norm
    w = q[0]
    vector = q[1:4]
    cross_1 = np.cross(vector, points)
    cross_2 = np.cross(vector, cross_1)
    return points + 2.0 * (w * cross_1 + cross_2)


def _add_earth_surface(fig: go.Figure) -> None:
    radius_km = EARTH_RADIUS_M / 1000.0
    theta = np.linspace(0.0, 2.0 * np.pi, 48)
    phi = np.linspace(0.0, np.pi, 24)
    x = radius_km * np.outer(np.cos(theta), np.sin(phi))
    y = radius_km * np.outer(np.sin(theta), np.sin(phi))
    z = radius_km * np.outer(np.ones_like(theta), np.cos(phi))
    fig.add_trace(
        go.Surface(
            x=x,
            y=y,
            z=z,
            name="Earth",
            colorscale=[[0.0, "#dbeafe"], [1.0, "#93c5fd"]],
            showscale=False,
            opacity=0.72,
        )
    )


def _moon_center_from_environment(row: pd.Series) -> np.ndarray:
    spacecraft_position_km = np.array(
        [row["x_eci_m"], row["y_eci_m"], row["z_eci_m"]],
        dtype=float,
    ) / 1000.0
    moon_hat = np.array([row["moon_hat_x"], row["moon_hat_y"], row["moon_hat_z"]], dtype=float)
    moon_hat = moon_hat / np.linalg.norm(moon_hat)
    return spacecraft_position_km + moon_hat * float(row["moon_range_m"]) / 1000.0


def _add_moon_surface(fig: go.Figure, center_km: np.ndarray) -> None:
    radius_km = 1737.4
    theta = np.linspace(0.0, 2.0 * np.pi, 36)
    phi = np.linspace(0.0, np.pi, 18)
    x = center_km[0] + radius_km * np.outer(np.cos(theta), np.sin(phi))
    y = center_km[1] + radius_km * np.outer(np.sin(theta), np.sin(phi))
    z = center_km[2] + radius_km * np.outer(np.ones_like(theta), np.cos(phi))
    fig.add_trace(
        go.Surface(
            x=x,
            y=y,
            z=z,
            name="Moon",
            colorscale=[[0.0, "#78716c"], [0.55, "#d6d3d1"], [1.0, "#f5f5f4"]],
            showscale=False,
            opacity=0.92,
        )
    )


def _line_chart(
    frame: pd.DataFrame,
    x: str,
    y: list[str],
    title: str,
    y_title: str,
) -> go.Figure:
    fig = go.Figure()
    for column in y:
        if column in frame.columns:
            fig.add_trace(go.Scatter(x=frame[x], y=frame[column], mode="lines", name=column))
    fig.update_layout(
        title=title,
        height=340,
        margin={"l": 0, "r": 0, "t": 42, "b": 0},
        template="plotly_white",
        xaxis_title=x,
        yaxis_title=y_title,
        legend={"orientation": "h", "y": 1.12},
    )
    return fig


def _windows_to_frame(windows: list[dict[str, float]], volume_bits: float = 0.0) -> pd.DataFrame:
    rows = []
    for index, window in enumerate(windows, start=1):
        duration_s = float(window["duration_s"])
        rows.append(
            {
                "window": index,
                "start_h": float(window["start_s"]) / 3600.0,
                "end_h": float(window["end_s"]) / 3600.0,
                "duration_min": duration_s / 60.0,
                "allocated_volume_mbit": volume_bits / 1.0e6 / max(1, len(windows)),
            }
        )
    return pd.DataFrame(rows)


def _sun_angle_proxy_deg(adcs: pd.DataFrame, environment: pd.DataFrame) -> pd.Series:
    body_x = np.array([1.0, 0.0, 0.0], dtype=float)
    angles = []
    for (_, attitude), (_, env_row) in zip(adcs.iterrows(), environment.iterrows(), strict=False):
        q = (attitude.q_w, attitude.q_x, attitude.q_y, attitude.q_z)
        body_x_eci = _rotate_points(body_x.reshape(1, 3), q)[0]
        sun_hat = np.array([env_row.sun_hat_x, env_row.sun_hat_y, env_row.sun_hat_z], dtype=float)
        sun_hat = sun_hat / np.linalg.norm(sun_hat)
        dot = float(np.clip(np.dot(body_x_eci, sun_hat), -1.0, 1.0))
        angles.append(np.degrees(np.arccos(dot)))
    return pd.Series(angles, index=adcs.index, name="sun_angle_proxy_deg")


def _summary_cards(summary: dict[str, Any], keys: list[tuple[str, str, float]]) -> None:
    columns = st.columns(len(keys))
    for column, (label, key, scale) in zip(columns, keys, strict=True):
        value = summary.get(key, "n/a")
        if isinstance(value, float):
            column.metric(label, f"{value / scale:.3g}")
        else:
            column.metric(label, str(value))


def _as_dict(value: pd.DataFrame | dict) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise TypeError("Expected a dictionary payload")
    return value


def _as_frame(value: pd.DataFrame | dict) -> pd.DataFrame:
    if not isinstance(value, pd.DataFrame):
        raise TypeError("Expected a DataFrame payload")
    return value


def main() -> None:
    st.set_page_config(page_title="LunaLink Mission Dashboard", layout="wide")
    _install_style()

    st.title("LunaLink Mission Design Dashboard")
    st.caption(
        "Interactive preliminary spacecraft-system simulator for Project X. "
        "NASA/ECSS-inspired, not flight-qualified."
    )

    output_step_s = st.sidebar.select_slider(
        "Simulation output step",
        options=[120.0, 300.0, 600.0],
        value=600.0,
        format_func=lambda value: f"{value:.0f} s",
    )
    sample_stride = st.sidebar.slider("3D orbit sample stride", 1, 6, 1)

    data = _run_cached(output_step_s)
    config = _as_dict(data["config"])
    environment = _as_frame(data["environment"])
    eps = _as_frame(data["eps"])
    adcs = _as_frame(data["adcs"])
    validation = _as_frame(data["validation"])
    summaries = _as_dict(data["summaries"])

    failed = int((validation["status"] == "fail").sum())
    warned = int((validation["status"] == "warn").sum())
    passed = int((validation["status"] == "pass").sum())
    orbit_period_h = float(config["orbit"]["period_s"]) / 3600.0

    top_cols = st.columns(6)
    top_cols[0].metric("Validation", "PASS" if failed == 0 else "FAIL")
    top_cols[1].metric("Pass", passed)
    top_cols[2].metric("Warn", warned)
    top_cols[3].metric("Fail", failed)
    top_cols[4].metric("Period h", f"{orbit_period_h:.4f}")
    top_cols[5].metric("Duration h", f"{environment['t_s'].iloc[-1] / 3600.0:.1f}")

    st.markdown(
        """
        <div class="lunalink-callout">
        Built for the Project X brief: fixed mission parameters, all four subsystems,
        adjustable Python GUI, 3+ orbit simulation, and explicit assumptions.
        </div>
        """,
        unsafe_allow_html=True,
    )

    tabs = st.tabs(["Mission", "Orbit 3D", "EPS", "TCS", "ADCS", "TT&C", "Evidence"])

    with tabs[0]:
        left, right = st.columns([1.15, 1.0])
        with left:
            st.subheader("Spacecraft Configuration")
            attitude_index = st.slider(
                "Spacecraft attitude sample",
                min_value=0,
                max_value=len(adcs) - 1,
                value=len(adcs) - 1,
                key="mission_attitude_sample",
            )
            attitude = adcs.iloc[attitude_index]
            q = (attitude.q_w, attitude.q_x, attitude.q_y, attitude.q_z)
            st.plotly_chart(build_spacecraft_figure(config, q), use_container_width=True)
            asset_path = Path("assets/lunalink_spacecraft_model.stl")
            if asset_path.exists():
                st.download_button(
                    "Download LunaLink STL model",
                    data=asset_path.read_bytes(),
                    file_name=asset_path.name,
                    mime="model/stl",
                )
        with right:
            st.subheader("Fixed Mission Specifications")
            st.dataframe(mission_spec_table(config), hide_index=True, use_container_width=True)
            st.subheader("Project X Coverage")
            st.dataframe(pd.DataFrame(PROJECT_SCOPE_ROWS), hide_index=True,
                         use_container_width=True)

    with tabs[1]:
        st.subheader("3D Orbit Visualizer")
        st.plotly_chart(build_orbit_figure(environment, sample_stride), use_container_width=True)
        orbit_plot = environment.assign(
            time_h=environment["t_s"] / 3600.0,
            altitude_km=environment["altitude_m"] / 1000.0,
            elevation_deg=environment["gs_elevation_rad"] * RAD2DEG,
            contact=environment["gs_contact_flag"].astype(int),
            eclipse=environment["eclipse_flag"].astype(int),
        )
        plot_cols = st.columns([1.0, 1.0])
        with plot_cols[0]:
            st.plotly_chart(
                _line_chart(
                    orbit_plot,
                    "time_h",
                    ["altitude_km", "elevation_deg"],
                    "Altitude And Ground-Station Elevation",
                    "km / deg",
                ),
                use_container_width=True,
            )
        with plot_cols[1]:
            st.plotly_chart(
                _line_chart(
                    orbit_plot,
                    "time_h",
                    ["contact", "eclipse"],
                    "Contact And Eclipse Flags",
                    "flag",
                ),
                use_container_width=True,
            )
        st.plotly_chart(build_ground_track_figure(environment), use_container_width=True)

    with tabs[2]:
        st.subheader("Electrical Power System")
        controls, plots = st.columns([0.38, 0.62])
        with controls:
            array_area = st.slider("Array area m2", 3.0, 8.0, 6.0, 0.25)
            battery_kwh = st.slider("Battery capacity kWh", 2.0, 8.0, 4.5, 0.25)
            peak_duty = st.slider("Peak/payload duty cycle", 0.0, 0.5, 0.15, 0.01)
            safe_load = st.slider("Safe load W", 300.0, 700.0, 500.0, 25.0)
            nominal_load = st.slider("Nominal load W", 650.0, 1000.0, 800.0, 25.0)
            peak_load = st.slider("Peak relay load W", 1000.0, 1400.0, 1200.0, 25.0)
            pointing_mode = st.selectbox("Array pointing", ["sun_tracking", "fixed_eci"])
        eps_variant, eps_summary = run_eps(
            environment,
            EpsConfig(
                array_area_m2=array_area,
                battery_capacity_kwh=battery_kwh,
                peak_duty_cycle=peak_duty,
                safe_load_w=safe_load,
                nominal_load_w=nominal_load,
                peak_load_w=peak_load,
                array_pointing_mode=pointing_mode,
            ),
        )
        with plots:
            _summary_cards(
                eps_summary,
                [
                    ("Min SOC", "min_soc", 1.0),
                    ("Array EOL W", "array_eol_power_w", 1.0),
                    ("Unserved MJ", "unserved_energy_j", 1.0e6),
                    ("Curtail MJ", "curtailed_energy_j", 1.0e6),
                ],
            )
            eps_plot = eps_variant.assign(time_h=eps_variant["t_s"] / 3600.0)
            st.plotly_chart(
                _line_chart(
                    eps_plot,
                    "time_h",
                    ["solar_power_w", "load_power_w", "net_power_w"],
                    "Generation, Load, And Net Power",
                    "W",
                ),
                use_container_width=True,
            )
            st.plotly_chart(
                _line_chart(
                    eps_plot,
                    "time_h",
                    ["battery_soc", "array_incidence_factor"],
                    "Battery SOC And Array Incidence",
                    "fraction",
                ),
                use_container_width=True,
            )
        st.dataframe(
            pd.DataFrame(
                [
                    {"mode": "safe", "power_w": safe_load},
                    {"mode": "nominal", "power_w": nominal_load},
                    {"mode": "peak relay", "power_w": peak_load},
                ]
            ),
            hide_index=True,
            use_container_width=True,
        )

    with tabs[3]:
        st.subheader("Thermal Control System")
        controls, plots = st.columns([0.36, 0.64])
        with controls:
            coating_mode = st.selectbox(
                "Surface coating scenario",
                ["baseline mixed", "white", "black", "OSR/FEP", "MLI"],
            )
            power_scale = st.slider("Internal dissipation scale", 0.5, 1.3, 1.0, 0.05)
            conductance = st.slider("Internal conductance W/m2/K", 3.0, 12.0, 6.0, 0.5)
        thermal_config = (
            ThermalConfig(
                face_coatings=default_face_coatings(),
                internal_conductance_w_m2_k=conductance,
            )
            if coating_mode == "baseline mixed"
            else ThermalConfig(coating=coating_mode, internal_conductance_w_m2_k=conductance)
        )
        thermal_variant, thermal_summary = run_thermal(
            environment,
            power_w=eps["load_power_w"] * power_scale,
            config=thermal_config,
        )
        with plots:
            _summary_cards(
                thermal_summary,
                [
                    ("Worst margin K", "worst_operating_margin_k", 1.0),
                    ("Max internal K", "max_internal_temp_k", 1.0),
                    ("Min external K", "min_external_temp_k", 1.0),
                    ("Limit flag", "component_limit_flag", 1.0),
                ],
            )
            thermal_plot = thermal_variant.assign(time_h=thermal_variant["t_s"] / 3600.0)
            st.plotly_chart(
                _line_chart(
                    thermal_plot,
                    "time_h",
                    [
                        "temp_internal_c",
                        "temp_x_pos_c",
                        "temp_x_neg_c",
                        "temp_y_pos_c",
                        "temp_y_neg_c",
                        "temp_z_pos_c",
                        "temp_z_neg_c",
                    ],
                    "Internal And Six-Face Temperature Response",
                    "deg C",
                ),
                use_container_width=True,
            )
        st.json(thermal_summary, expanded=False)

    with tabs[4]:
        st.subheader("Attitude Determination And Control")
        controls, plots = st.columns([0.36, 0.64])
        with controls:
            tumble_deg_s = st.slider("Initial tumble deg/s", 1.0, 15.0, 10.0, 0.5)
            dipole = st.slider("Magnetorquer max dipole A m2", 100.0, 600.0, 400.0, 25.0)
            wheel_capacity = st.slider("Wheel momentum capacity Nms", 4.0, 20.0, 12.0, 1.0)
            sample_index = st.slider("Orientation sample", 0, len(adcs) - 1, len(adcs) - 1)
        adcs_variant, adcs_summary = run_adcs(
            environment,
            AdcsConfig(
                initial_tumble_rad_s=tumble_deg_s / RAD2DEG,
                magnetorquer_max_dipole_a_m2=dipole,
                wheel_momentum_capacity_nms=wheel_capacity,
            ),
        )
        adcs_plot = adcs_variant.assign(
            time_h=adcs_variant["t_s"] / 3600.0,
            sun_angle_proxy_deg=_sun_angle_proxy_deg(adcs_variant, environment),
        )
        with plots:
            _summary_cards(
                adcs_summary,
                [
                    ("Final deg/s", "final_angular_speed_deg_s", 1.0),
                    ("Max wheel Nms", "max_wheel_momentum_nms", 1.0),
                    ("Max torque Nm", "max_total_torque_nm", 1.0),
                    ("Wheel sat", "wheel_saturated", 1.0),
                ],
            )
            attitude = adcs_variant.iloc[sample_index]
            q = (attitude.q_w, attitude.q_x, attitude.q_y, attitude.q_z)
            st.plotly_chart(build_spacecraft_figure(config, q), use_container_width=True)
            st.plotly_chart(
                _line_chart(
                    adcs_plot,
                    "time_h",
                    ["angular_speed_deg_s", "wheel_momentum_norm_nms", "sun_angle_proxy_deg"],
                    "Detumble, Wheel Momentum, And Sun-Angle Proxy",
                    "deg/s, Nms, deg",
                ),
                use_container_width=True,
            )
            st.plotly_chart(
                _line_chart(
                    adcs_plot,
                    "time_h",
                    [
                        "gravity_gradient_torque_x_nm",
                        "srp_torque_x_nm",
                        "drag_torque_x_nm",
                        "residual_magnetic_torque_x_nm",
                    ],
                    "Disturbance Torque Components",
                    "Nm",
                ),
                use_container_width=True,
            )
        st.info(
            "The baseline ADCS model validates detumble and disturbance momentum "
            "bookkeeping. The sun-angle curve is a visualization proxy, not a "
            "closed-loop pointing accuracy claim."
        )

    with tabs[5]:
        st.subheader("Telemetry, Tracking, And Command")
        controls, plots = st.columns([0.36, 0.64])
        xband_base = default_xband_link_config()
        uhf_base = default_uhf_link_config()
        with controls:
            xband_power = st.slider("X-band transmit power W", 10.0, 40.0,
                                    xband_base.tx_power_w, 1.0)
            xband_rate = st.select_slider(
                "X-band data rate Mbps",
                options=[25.0, 50.0, 100.0, 150.0],
                value=100.0,
            )
            noise_temp = st.slider("X-band system noise K", 80.0, 300.0,
                                   xband_base.system_noise_temp_k, 10.0)
            uhf_power = st.slider("UHF transmit power W", 5.0, 40.0, uhf_base.tx_power_w, 1.0)
            uhf_rate = st.select_slider("UHF data rate kbps", options=[2.0, 5.0, 10.0, 20.0],
                                        value=10.0)
        ttc_variant, ttc_summary = run_ttc(
            environment,
            {
                "xband": {
                    "tx_power_w": xband_power,
                    "data_rate_bps": xband_rate * 1.0e6,
                    "system_noise_temp_k": noise_temp,
                },
                "uhf": {"tx_power_w": uhf_power, "data_rate_bps": uhf_rate * 1.0e3},
            },
        )
        with plots:
            _summary_cards(
                ttc_summary,
                [
                    ("X margin dB", "xband_min_margin_db", 1.0),
                    ("UHF margin dB", "uhf_min_margin_db", 1.0),
                    ("X volume Gbit", "xband_data_volume_bits", 1.0e9),
                    ("Relay Gbit", "end_to_end_relay_volume_bits", 1.0e9),
                ],
            )
            ttc_plot = ttc_variant.assign(
                time_h=ttc_variant["t_s"] / 3600.0,
                xband_volume_gbit=ttc_variant["xband_cumulative_volume_bits"] / 1.0e9,
                uhf_volume_mbit=ttc_variant["uhf_cumulative_volume_bits"] / 1.0e6,
                gs_elevation_deg=ttc_variant["gs_elevation_rad"] * RAD2DEG,
            )
            st.plotly_chart(
                _line_chart(
                    ttc_plot,
                    "time_h",
                    ["xband_margin_db", "uhf_margin_db", "gs_elevation_deg"],
                    "Link Margins And Ground Elevation",
                    "dB / deg",
                ),
                use_container_width=True,
            )
            st.plotly_chart(
                _line_chart(
                    ttc_plot,
                    "time_h",
                    ["xband_volume_gbit", "uhf_volume_mbit"],
                    "Cumulative Data Volume",
                    "Gbit / Mbit",
                ),
                use_container_width=True,
            )
        budget_cols = [
            "xband_eirp_dbw",
            "xband_fspl_db",
            "xband_cn0_db_hz",
            "xband_ebn0_db",
            "xband_margin_db",
            "uhf_eirp_dbw",
            "uhf_fspl_db",
            "uhf_cn0_db_hz",
            "uhf_ebn0_db",
            "uhf_margin_db",
        ]
        st.dataframe(ttc_variant[budget_cols].describe().T, use_container_width=True)
        windows = _windows_to_frame(
            ttc_summary["xband_available_windows"],
            float(ttc_summary["xband_data_volume_bits"]),
        )
        st.dataframe(windows, hide_index=True, use_container_width=True)

    with tabs[6]:
        st.subheader("Validation And Evidence")
        st.dataframe(
            validation[["name", "status", "severity", "value", "criterion", "source_module"]],
            use_container_width=True,
            hide_index=True,
        )
        st.subheader("Assumptions")
        st.json(config, expanded=False)
        st.subheader("Baseline Summaries")
        st.json(summaries, expanded=False)
        st.subheader("Important Claim Boundary")
        st.warning(
            "This dashboard supports preliminary engineering trade studies and the "
            "Project X submission. Flight-qualified use requires independent "
            "GMAT/Orekit correlation, IV&V, and responsible authority acceptance."
        )


if __name__ == "__main__":
    main()
