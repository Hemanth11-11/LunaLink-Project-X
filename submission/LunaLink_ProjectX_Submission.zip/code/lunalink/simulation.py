"""Mission-level orchestration for LunaLink."""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from .adcs import run_adcs
from .config import MissionConfig, default_mission_config
from .environment import build_environment_table
from .eps import run_eps
from .thermal import ThermalConfig, default_face_coatings, run_thermal
from .ttc import run_ttc
from .validation import ValidationMetric, validate_environment_table, validate_subsystem_summaries


@dataclass(frozen=True)
class MissionResults:
    config: MissionConfig
    environment: pd.DataFrame
    eps: pd.DataFrame
    thermal: pd.DataFrame
    adcs: pd.DataFrame
    ttc: pd.DataFrame
    summaries: dict[str, dict]
    validation_metrics: list[ValidationMetric]


def run_mission(config: MissionConfig | None = None, include_j2: bool = True) -> MissionResults:
    mission_config = config or default_mission_config()
    environment = build_environment_table(mission_config, include_j2=include_j2)
    eps, eps_summary = run_eps(environment)
    ttc, ttc_summary = run_ttc(environment)
    thermal, thermal_summary = run_thermal(
        environment,
        power_w=eps["load_power_w"],
        config=ThermalConfig(face_coatings=default_face_coatings()),
    )
    adcs, adcs_summary = run_adcs(environment, mission_config)
    summaries = {
        "eps": eps_summary,
        "thermal": thermal_summary,
        "adcs": adcs_summary,
        "ttc": ttc_summary,
    }
    validation_metrics = [
        *validate_environment_table(mission_config, environment),
        *validate_subsystem_summaries(summaries, mission_config),
    ]
    return MissionResults(
        config=mission_config,
        environment=environment,
        eps=eps,
        thermal=thermal,
        adcs=adcs,
        ttc=ttc,
        summaries=summaries,
        validation_metrics=validation_metrics,
    )
